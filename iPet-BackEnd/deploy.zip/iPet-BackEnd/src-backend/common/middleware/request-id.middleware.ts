import { Injectable, NestMiddleware } from '@nestjs/common';
import { Request, Response, NextFunction } from 'express';
import { randomUUID } from 'crypto';

declare global {
    namespace Express {
        interface Request {
            requestId?: string;
        }
    }
}

@Injectable()
export class RequestIdMiddleware implements NestMiddleware {
    use(req: Request, res: Response, next: NextFunction) {
        // Use existing request ID from header or generate a new one
        const requestId = (req.headers['x-request-id'] as string) || randomUUID();

        req.requestId = requestId;
        res.setHeader('X-Request-Id', requestId);

        next();
    }
}
